###　webpack 入门学习笔记

一篇入门学习笔记，没有深度，有错误的话欢迎指正。

**概念**

引用webpack官网自己的描述（当然，不止于此）：

> At its core, *webpack* is a *static module bundler* for modern JavaScript applications. 
> webpack的核心是一个适用于现代JavaScript应用程序的静态模块打包程序。

上面这段话还提到了一个词 module（模块）。在模块化编程中，开发人员将不同的功能块拆分开来放到不同的模块中。每个模块有更少的代码，只需对外暴露外部需要的接口，将具体实现抽象、封装（高内聚，低耦合）。模块易于验证，调试和测试，对开发和合作开发更友好。

目前各种常用前端框架大都应用模块化开发。模块化开发随之而来的问题是，一个大型应用可能有几十个模块，还包含所需的图片、CSS等文件。如果不将这些内容进行打包、压缩。浏览器在加载页面时可能需要下载几十个资源才能将页面渲染出来。虽然现代浏览器性能强劲，但是也扛不住爆炸的文件数量。

webpack 的作用就是将这些分散开发的功能模块和各种文件，都当做 模块 处理。它会递归地构建一个依赖图，其中包含应用程序需要的每个模块，然后将所有这些模块打包到一个或多个包中。



**安装**

本地安装

```text
$ npm install webpack webpack-cli --save-dev
```

由于项目内安装，使用webpack直接在命令行执行会提示 Command not found

所以需要配置 npm 命令执行 webpack 命令（npm 会先查询项目内的webpack模块）

在项目 package.json 文件增加下面代码：

```json
"scripts": {
    "start": "webpack --config webpack.config.js"
}
```



**核心 webpack.config.js 配置文件**

webpack可以直接使用它自己的cli来执行打包构建任务。但是通常我们的项目需要配置很多插件或者规则来解析每个模块。使用cli输入命令时候极其不方便，所以推荐直接使用配置文件的方法来执行打包构建任务。

最简单的配置如下：

```js
const path = require('path')
module.exports = {
    entry: "./index.js",
    output: {
        path: path.join(__dirname, "./lib"),
        filename: "bundle.js"
    }
}
```

entry 字段：入口文件。告诉webpack应该从哪个模块开始构建其内部依赖关系图。

webpack会从 entry 所指的文件开始分析，首先分析入口文件依赖（使用 import/require 等方式 引入的各个模块），然后递归分析依赖文件，最后构建内部依赖关系图。

output 字段： 输出配置。 告诉webpack应该把打包后的文件如何输出。其中 path 为绝对路径。

上面的这段配置为：以 ./index.js 为入口文件，分析依赖并打包输出到目录 ./lib 下，打包后的文件名为 bundle.js。

执行命令前，项目目录如下：

![img](https://pic3.zhimg.com/80/v2-208026aada6ba1cf53dc1a6a049ae5c2_hd.jpg)

然后执行我们上面配置过的 npm 命令

```text
# 实际会执行 webpack --config webpack.config.js
$ npm start
```

执行命令后，命令行反馈：

![img](https://pic3.zhimg.com/80/v2-74dbad3ece1fc3f025be71c3a1a80c9e_hd.jpg)

项目目录改变为：（其中 ./lib/bundle.js为上面配置的输出文件）

![img](https://pic4.zhimg.com/80/v2-5f0a270951e380d41dda2be55e90476b_hd.jpg)

打包成功！（可以多建几个文件引入到 index.js 尝试一下）



**Loaders**

loader 用于加载某些资源文件。 因为webpack 本身只能打包commonjs规范的js文件，对于其他资源例如 css，图片，或者其他的语法集，比如 jsx， coffee，是没有办法加载的。 这就需要对应的loader将资源转化，加载进来。从字面意思也能看出，loader是用于加载的，它作用于一个个文件上。

而为了简洁和效率，为了使用新特性，大多数情况下我们会使用ES6/7的新语法来写Javascript。为了合作开发和更好的维护，我们甚至会选择一个扩展语言来写CSS。总之，这些东西都需要在打包之前进行编译转码处理，让webpack认识，也让浏览器更好执行。

webpack 使用 Loader 来解决这个问题：（Loader作用不只是转码）

loader使用之前需要先安装

```text
# 以 babel-loader 和 css-loader 为例，webpack有很多loader可用
$ npm install babel-loader --save-dev
$ npm install css-loader --save-dev
```

然后配置（在 webpack.config.js 中添加 module 字段。在module 字段的 rules 字段中 添加匹配规则和loader）如下：

```js
const path = require('path')
module.exports = {
    entry: "./index.js",
    output: {
        path: path.join(__dirname, "./lib"),
        filename: "bundle.js"
    },
    module: {
        rules: [
            { test: /\.jsx$/, use: 'babel-loader' },
            { test: /\.css$/, use: 'css-loader' }
        ]
    }
}
```

test 对应的是一个 正则表达式，用来匹配需要使用 loader 进行转码的文件。 use 设置的是 使用哪个 loader 进行转码。

上面的配置为：

将文件名以 .jsx 结尾的文件，使用 babel-loader 进行转码加载，然后进行打包输出。

将文件名以 .css 结尾的文件，使用 css-loader 加载，然后进行打包输出。



rules 还可以进行更详细设置，单个规则使用多个 loader，配置正则匹配的文件范围，增加配置项options等。 如下：（此处不再详解，我也没搞的特别清楚）

```js
const join = require('path').join
module.exports = {
    entry: "./index.js",
    output: {
        path: join(__dirname, "./lib"),
        filename: "bundle.js"
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                loaders: ['babel-loader'],
                include: [join(__dirname, 'client'), join(__dirname, 'server')],
                // loader: 'babel-loader'
                // options: {
                //     presets: ['env'],
                //     plugins: []
            // }
        }, {
                test: /\.css$/, 
                use: 'css-loader'  
        }]
    }
}
```

loaders 数组： 配置多个 loader 共同起作用

include 数组： 添加当前规则查找匹配的文件范围

loader 字符串：配置单个 loader

options 对象 ：针对 loader 字段配置的 loader 进行一些配置



babel-loader 的出现又 绕回了 babel 的使用方法。关于 babel 其实还有很多配置项可以详细展开。 之前写了一篇 [Babel 入门学习笔记](https://zhuanlan.zhihu.com/p/35888257) 可以做简单了解。后续还会记录一下 webpack 和 babel 配合使用的学习内容。



**Plugins （插件）**

插件这个东西比较好理解。就是用来自动化完成一些对文件的操作处理，做一下打包前、打包后的处理工作，或者压缩等等。

先举一个最简单的例子：

打包后自动生成html文件 的插件，安装：

```text
$ npm install html-webpack-plugin --save-dev
```

然后在 webpack.config.js中引入插件：

```js
// 使用 require 引入插件
const HtmlWebpackPlugin = require('html-webpack-plugin')

const join = require('path').join
module.exports = {
    entry: "./index.js",
    output: {
        path: join(__dirname, "./lib"),
        filename: "bundle.js"
    },
    module: {
        rules: [{
            test: /\.(js|jsx)$/,
            loaders: ['babel-loader'],
            include: [join(__dirname, 'client'), join(__dirname, 'server')],
            // loader: 'babel-loader'
            // options: {
            //     presets: ['env'],
            //     plugins: []
            // }
        }]
    },
    // 在 plugins 字段的数组中加入插件
    plugins:[
      new HtmlWebpackPlugin()
    ]
}
```

插件配置完成。

这个插件将会在你项目打包的输出目录 生成一个 .html 文件。内容如下：

```html
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Webpack App</title>
  </head>
  <body>
    <script src="bundle.js"></script> 
  </body>
</html>
```

可以看到，生成的文件已经自动将 打包后的 js 文件通过script标签引入到 html 中了。

除此之外，还可以通过对插件传入配置参数 来配置生成的 html 的一些内容。甚至使用一个预先写好的模板来生成html。

```js
plugins:[
      new HtmlWebpackPlugin({
          template: './src/index.html'
      })
    ]
```

每个插件的配置都需要单独浏览插件文档。这只是最简单的一个例子。

下面是三个常用插件：

```text
# 清理 output 文件
$ npm install clean-webpack-plugin --save-dev
# 压缩 css 及 js 文件
$ npm install uglifyjs-webpack-plugin optimize-css-assets-webpack-plugin --save-dev
```

此外 webpack本身也内置了一些插件：

详情可查看：

Pluginswebpack.js.org



**Mode**

在webpack.config.js 的配置中有一个 mode 字段。配置对应的 mode，wepback可以提供内置的对应模式的优化。

```text
module.exports = {
  mode: 'production'
};
```

详细的优化可参考官方文档，很详细，不做赘述：

Modewebpack.js.org



**小结**

webpack 还有很多深入的内容需要学习，真正项目使用时候的配置也更加复杂。

毕竟 webpack配置工程师 不是那么容易达成的。

想了想 devServer 内容 还是单独拿出来写一篇笔记比较好。此文不见得都是正确的，希望指正。写东西有助于知识梳理，写的时候才知道，自己理解的太浅。

发布于 2018-04-24 from <https://zhuanlan.zhihu.com/p/35896584>



# 从头开始创建一个 React 应用

<https://zhuanlan.zhihu.com/p/36137966>