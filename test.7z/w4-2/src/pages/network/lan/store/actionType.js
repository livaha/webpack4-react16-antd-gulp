export const LAN_IPADDR = 'lan_ipaddr';
export const LAN_NETMASK = 'lan_netmask';
export const LAN_MSG = 'lan_msg';
export const LAN_SHOW_PROGRESS = 'showProgress'


