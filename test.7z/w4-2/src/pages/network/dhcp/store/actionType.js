//export const LAN_IPADDR = 'lan_ipaddr';
//export const LAN_NETMASK = 'lan_netmask';
export const DHCP_MSG = 'dchp_msg';
export const ARP_LIST = 'arp_list';
export const DHCP_ENABLE = 'dhcp_enable';


