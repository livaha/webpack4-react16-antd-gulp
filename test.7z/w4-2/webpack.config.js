const path = require("path");
const webpack = require("webpack");

let GLOBALS = {
  DEFINE_OBJ: {
    'process.env.NODE_ENV': JSON.stringify('development'),
    __DEV__: true,
  },

  folders: {
    SRC: path.resolve(__dirname, 'src'),
    COMPONENT: path.resolve(__dirname, 'src/components'),
    BUILD: path.resolve(__dirname, 'build'),
    BOWER: path.resolve(__dirname, 'bower_components'),
    NPM: path.resolve(__dirname, 'node_modules'),
  },
};

let config = {
  // more info:https://webpack.github.io/docs/build-performance.html#sourcemaps and https://webpack.github.io/docs/configuration.html#devtool
  /**对小到中型的项目中，`eval-source-map`是一个很好的选项，再次强调你只应该开发阶段使用它 */
  devtool: 'cheap-eval-source-map',  
  /**让浏览器监听你的代码的修改，并自动刷新显示修改后的结果 */
  devServer: {
    contentBase: "./public",//本地服务器所加载的页面所在的目录
    historyApiFallback: true,//不跳转
    inline: true//实时刷新
  },
  entry: {
    index: [
       // necessary for hot reloading with IE:
    //  'eventsource-polyfill',
    //  'react-hot-loader/patch',

      './src/index.js',
    ],
  },
  // necessary per https://webpack.github.io/docs/testing.html#compile-and-test
  target: 'web',
  output: {
    path: GLOBALS.folders.BUILD,
    publicPath: '/',
    filename: 'scripts/bundle.js',
  },
  module: {
    rules: [
      {
        test: /\.png$/,
        use: [
          {
            loader: 'url-loader',
          }
        ]
      },

      {
        test: /\.jpg$/,
        use: [
          {
            loader: 'url-loader',
          }
        ]
      },

      {
        test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        use: [
          {
            loader: 'url-loader',
          }
        ]
      },

      {
        test: /\.(ttf|eot|svg|cur)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        use: [
          {
            loader: 'file-loader',
          }
        ]
      },

      {
        test: /\.css$/,
        use: [
          {
            loader: "style-loader"
          },
          {
            loader: "css-loader"
          },
          {
            loader: "postcss-loader",
          },
        ]
      },

      {
        test: /\.(scss|sass)$/,
        use: [
          {
            loader: "style-loader"
          },
          {
            loader: "css-loader"
          },
          {
            loader: "postcss-loader",
          },
          {
            loader: "sass-loader",
            options: {
              includePaths: ['shared/scss']
            }
          }
        ]
      },
      {
        test: /\.less$/,
        loader: 'style-loader!css-loader!postcss-loader!less-loader?{modifyVars:{"@primary-color":"#00CC66"}}',//主题颜色
        //loader: 'style!css!postcss!less?{modifyVars:{"@primary-color":"#00CC66"}}',//主题颜色

      },
      {
        test: /\.(js|jsx)?$/,
        exclude:/node_modules/,
        use: [
          {
            loader: "babel-loader",
            options: {
              presets: [
                "env"
              ],
            }
          },
        ]
      },
    ] 
  },
  resolve: {
    extensions: ['.js', '.jsx'],
    modules: [
      path.resolve(__dirname, "node_modules"),
      path.resolve(__dirname, "shared"),
      path.resolve(__dirname, "packages"),
    ],
    alias: {
      // Support React Native Web
      // https://www.smashingmagazine.com/2016/08/a-glimpse-into-the-future-with-react-native-for-web/
      'react-native': 'react-native-web',
      // 全局相对路径别名，处理相对路径过长和繁琐问题
      '@': GLOBALS.folders.SRC
    },
  },
  performance: {
    /**为了加大文件允许体积，提升报错门栏。 */
    hints: false, // enum
    maxAssetSize: 24000000, // int (in bytes),
    maxEntrypointSize: 40000000, // int (i bytes
  },
  devServer: {
    contentBase: path.join(__dirname,'public'),
    port: 3000,
    publicPath: "http://localhost:3000/build"
  },
  /**loaders是在打包构建过程中用来处理源文件的（JSX，Scss，Less..），一次处理一个，插件并不直接操作单个文件，它直接对整个构建过程其作用 */
  plugins: [ 
    new webpack.LoaderOptionsPlugin({
      debug: true,

      // set to false to see a list of every file being bundled.
      noInfo: true,
    }),
    new webpack.DefinePlugin(GLOBALS.DEFINE_OBJ),
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NoEmitOnErrorsPlugin(),
   ]
};


module.exports = config;