export const CHANGE_LOG_DATA = 'change_log_data';
export const CHANGE_SYS_LOG = 'change_sys_log';

export const CHANGE_SYS_ENABLE = 'change_sys_enable';
export const CHANGE_LOG_SIZE = 'change_log_size';

