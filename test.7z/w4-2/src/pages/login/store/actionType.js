export const CAHNGE_LOGIN = 'login/CHANGE_LOGIN';
export const LOGOUT = 'login/CHANGE_LOGOUT';