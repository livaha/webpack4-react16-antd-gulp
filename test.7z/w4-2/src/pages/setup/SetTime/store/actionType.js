export const NTP_TIME_OF_DAY = 'time_of_day';
export const NTP_TIME_ZONE = 'time_zone';
export const NTP_ENABLE = 'ntp_enable';
export const NTP_SERVER = 'ntp_server';
export const INIT_NTP_DATA = 'init_ntp_data'
