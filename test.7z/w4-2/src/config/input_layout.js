export const formItemLayout = {
    labelCol:{
        xs:24,
        sm:24,
        md: 8,
    },
    wrapperCol:{
        xs:24,
        sm:24,
        md:8,
    }
}
export const  tailFormItemLayout = {
    wrapperCol:{
        xs:24,
        sm:24,
        md:{
            span:22,
            offset:8
        },
    }
}

