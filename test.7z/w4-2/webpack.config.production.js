const path = require("path");
const webpack = require("webpack");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const HtmlWebpackIncludeAssetsPlugin = require('html-webpack-include-assets-plugin');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');

let GLOBALS = {
  DEFINE_OBJ: {
    'process.env.NODE_ENV': JSON.stringify('development'),
    __DEV__: true,
  },

  folders: {
    SRC: path.resolve(__dirname, 'src'),
    COMPONENT: path.resolve(__dirname, 'src/components'),
    BUILD: path.resolve(__dirname, 'build'),
    BOWER: path.resolve(__dirname, 'bower_components'),
    NPM: path.resolve(__dirname, 'node_modules'),
  },
};

module.exports = {


  entry: {
    app: ['./src/index_pub.js'],
    //vendors: vendorList
  },
  module: {
    rules: [
      {
        test: /\.png$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              mimetype: 'image/png',
              limit: 11000,
              name: 'images/[name].[ext]',
            },
          }
        ]
      },

      {
        test: /\.(jpg|gif)$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              name: 'images/[hash].[ext]',
            },
          }
        ]
      },

      {
        test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              name: 'font/[hash].[ext]',
              limit: 11000,
              mimetype: 'mimetype=application/font-woff',
            }
          }
        ]
      },

      {
        test: /\.(ttf|eot|svg|cur)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: 'font/[hash].[ext]',
            }
          }
        ]
      },

      {
        test: /\.css$/,
        use: ExtractTextPlugin.extract({
          use: [
            "css-loader",
            "postcss-loader",
          ],
        })
      },

      {
        test: /\.(scss|sass)$/,
        use: ExtractTextPlugin.extract({
          use: [
            {
              loader: "css-loader"
            },
            {
              loader: "postcss-loader",
            },
            {
              loader: "sass-loader",
              options: {
                includePaths: ['shared/scss']
              }
            }
          ],
        })
      },

      {
        test: /\.less$/,
        loader: ExtractTextPlugin.extract(
            'css?sourceMap&!' +
            'postcss!' +
            'less-loader?{"sourceMap":true,"modifyVars":{"@primary-color":"#00CC66"}}'
        ),
      },
      {
        test: /\.(js|jsx)?$/,
        include: [
          path.resolve(__dirname, "src"),
          path.resolve(__dirname, "shared"),
          path.resolve(__dirname, "packages"),
        ],
        use: [
          {
            loader: "babel-loader",
            options: {
              presets: [
                "env"
              ],
            }
          },
        ]
      },
    ] 
  },
  resolve: {
    extensions: ['.js', '.jsx'],
    modules: [
      path.resolve(__dirname, "node_modules"),
      path.resolve(__dirname, "shared"),
      path.resolve(__dirname, "packages"),
    ],
    alias: {
      // Support React Native Web
      // https://www.smashingmagazine.com/2016/08/a-glimpse-into-the-future-with-react-native-for-web/
      'react-native': 'react-native-web',
      // 全局相对路径别名，处理相对路径过长和繁琐问题
      '@': GLOBALS.folders.SRC
    },
  },
  output: {
    path: GLOBALS.folders.BUILD,
    publicPath: '/',
    filename: 'scripts/[name].bundle.js',
    chunkFilename: 'scripts/[id].bundle.js' //dundle生成的配置
  },
  plugins: [
    new webpack.optimize.ModuleConcatenationPlugin(),
    new webpack.LoaderOptionsPlugin({
      debug: false,
      cache: true,
      // set to false to see a list of every file being bundled.
      noInfo: true,

      options: {
        context: __dirname,
      }
    }),
  //  new webpack.DllReferencePlugin({
  //    context: "dll",
  //    manifest: require("./src/config/scripts/vendors-manifest.json")
  //  }),

    new webpack.DefinePlugin(GLOBALS.DEFINE_OBJ),
    // new webpack.optimize.CommonsChunkPlugin({
    //   name: ['vendors'], // 将公共模块提取，生成名为`vendors`bundle
    //   chunks: ['vendors', 'app'], //提取哪些模块共有的部分,名字为上面的vendor
    //   minChunks: 2, // Infinity // 提取至少*个模块共有的部分
    // }),
    new ExtractTextPlugin({
      filename: "styles/fixlink.css",
      allChunks: true
    }),
    new UglifyJSPlugin(),
    new HtmlWebpackIncludeAssetsPlugin({
      assets: ['scripts/vendors.bundle.js'],
      append: false,
      hash: true
    }),
    new HtmlWebpackPlugin({ //根据模板插入css/js等生成最终HTML
      favicon: 'src/favicon.ico', //favicon存放路径
      filename: 'index.html', //生成的html存放路径，相对于 path
      template: 'src/index_pub.html', //html模板路径
      inject: true, //允许插件修改哪些内容，包括head与body
      hash: true, //为静态资源生成hash值
      //chunks: ['manifest', 'vendors', 'app'], //需要引入的chunk，不配置就会引入所有页面的资源.名字来源于你的入口文件
      minify: { //压缩HTML文件
        removeComments: false, //移除HTML中的注释
        collapseWhitespace: true //删除空白符与换行符
      }
    }),
  ],
};

